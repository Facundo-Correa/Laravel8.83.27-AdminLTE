Exportando registros 
1|1|Tatuadores Buenos Aires|1|
2|2|Norte - Salamone Alejandro|1|
3|3|Oeste - Scelza Marcelo|1|
4|4|Sur - Chessa Arturo|1|
5|5|Sur - Lentini Francisco|1|
6|6|Sur - Mouta Adolfo|1|
7|7|Sur - Rinaldi Horacio|1|
8|8|Capital y Gran Bs.As.|1|
9|20|Chaco|0|
10|21|Chubut|0|
11|22|Córdoba|0|
12|23|Corrientes|0|
13|24|Entre Ríos|0|
14|25|Jujuy|0|
15|26|La Pampa|0|
16|27|Mendoza|0|
17|28|Neuquen|0|
18|29|Río Negro|0|
19|30|Salta|0|
20|31|San Juan|0|
21|32|San Luis|0|
22|33|Santa Cruz|0|
23|34|Santa Fe|0|
24|35|Rosario|0|
25|36|Santiago del Estero|0|
26|37|Tierra del Fuego|0|
27|38|Tucumán|0|
28|50|25 de Mayo|0|
29|51|Bahía Blanca|0|
30|52|La Plata|0|
31|53|Lincoln|0|
32|54|Mar del Plata|0|
33|55|Miramar|0|
34|56|Necochea|0|
35|57|Olavarría|0|
36|58|San Nicolás|0|
37|59|Tandil|0|
38|60|Tres Arroyos|0|
39|99|No Corresponde|0|
40|9|Zona Oeste - Domínguez Héctor Horacio|1|
41|61|Ostende - Bs.As.|0|
42|10|Zona Oeste - Bustos Andres|1|
43|11|Buenos Aires|1|
44|39|La Rioja|0|
45|62|Extranjero|0|
