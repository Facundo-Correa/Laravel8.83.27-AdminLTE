Exportando registros 
1|AM|Amarilla|SI|
2|AP|APROBADO|SI|
3|AZ|Azul|SI|
4|B|BUENA|SI|
5|BCA|BLANCA|SI|
6|Desc.|Descalificado|NO|
7|E|EXCELENTE|SI|
8|I|INSUFICIENTE|NO|
9|MB|MUY BUENA|SI|
10|R|REPROBADO|NO|
11|Ret.c/AuT.|Ret.c/Aut.|NO|
12|Ret.s/aut.|Ret.s/Aut.|NO|
13|RO|Roja|SI|
14|S|SUFICIENTE|SI|
15|VA|VA Exc.Seleccionado|SI|
