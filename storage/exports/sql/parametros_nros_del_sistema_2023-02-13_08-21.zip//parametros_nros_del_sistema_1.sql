Exportando registros 
1|003|Nro_DServicio|30000|66059|
2|007|Nro_POA|245935|385479|
3|020|Nro_Transferencia|1|136354|
4|NCD|Nota de credito Delegacion|1|63581|
5|NCA|Nota de credito Agrupacion|1|36358|
6|NCE|Nro Criadero Extranjero|9999999|10004176|
7|NCN|Nro Criadero Nacional|8209|9966|
8|002|Nro_TMacho|1|2437|
9|009|Nro_Transfer_Pedigree|1|25853|
10|010|Nro_Pedigree_Original|1|12075|
11|011|Nro_Transfer|1|5162|
12|013|Nro_Pedigree_Duplicado|1|1577|
13|004|Nro_Arrendamiento_CaC|1|2815|
14|001|Nro_VFDServ|1|19893|
15|016|Nro_Inscrip_Ex_DCF|1|25612|
16|017|Nro_Inscrip_Ex_Seleccion|1|10787|
17|015|Nro_Inscrip_Ex_AptoCria|1|13121|
18|018|Nro_Inscrip_Ex_Superior|1|1000|
19|019|Nro_Inscrip_Ex_CAB2|1|6194|
20|005|Nro_Arrendamiento_SaC|1|1633|
21|006|Nro_Arrendamiento_NSaC|1|1791|
22|012|Nro_RegCriadero|1|2758|
23|023|Otras Sociedades|1|1811|
24|DBA|Nro_Deleg_Bs_As|999003|999003|
25|CGE|Nro_Cliente_Generico|777777|777777|
26|022|Nro_Inscrip_Torneos|1|29471|
27|TSF|Torneos sin Factura|1|64981|
28|TDO|Transferencias de dominio|0|88463|
29|024|DCF  de Codo|1|7432|
30|SFW|Torneos Web sin Factura|1|100001|
31|PDI|Pedigre Digital|1|15991|
