Exportando registros 
1|001|Aspoa|1|0|
2|002|Bahia Blanca|1|0|
3|003|Buenos Aires|1|0|
4|004|Caleta Olivia|1|0|
5|005|Chaco|1|0|
6|006|Club Acoan|1|0|
7|007|Club Amoa|1|0|
8|008|Club Arcoa|1|0|
9|009|Club Coam|1|0|
10|010|Club Coane|1|0|
11|011|Club Tucumano|1|0|
12|012|Comarca Andina|1|0|
13|013|Comodoro Rivadavia|1|0|
14|014|Corrientes|1|0|
15|015|Del Comahue|1|0|
16|016|Fueguina del POA (AFOA)|1|0|
17|017|Jujuy (AJPOA)|1|0|
18|018|La Pampa|1|0|
19|019|Ovejeristas del Río Uruguay|1|0|
20|020|Paraná|1|0|
21|021|Club COA|1|0|
22|022|Puerto Madryn|1|0|
23|023|Riojana|1|0|
24|024|Salta|1|0|
25|025|San Juan|1|0|
26|026|San Luis (APPPOA)|1|0|
27|027|Santiago del Estero|1|0|
28|028|Tierra del Fuego|1|0|
29|029|Trelew|1|0|
30|030|Tres Arroyos|1|0|
31|999| No Corresponde|1|0|
32|031|Río Negro|1|0|
33|032|Rio Gallegos|1|0|
34|033|Criadores de la Cordillera|1|0|
35|034|Rafaela|1|0|
36|051|Die Zeit|0|0|
37|035|A.CA.P.O.A|1|0|
38|036|AG.EL BOLSON|1|0|
39|037|ALTO VALLE|1|0|
40|038|DELEG.LINCOLN|1|0|
41|607|DELEG.JUNIN|1|0|
42|040|STEFENELLI|1|0|
43|039|ANOA GENERAL PICO|1|0|
