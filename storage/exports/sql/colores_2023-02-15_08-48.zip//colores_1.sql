Exportando registros 
1|1|NEGRO|
2|2|GRIS|
3|3|MARRON|
