Exportando registros 
1|1|IPO1|3|1|
2|2|IPO2|3|2|
3|3|IPO3|3|3|
4|4|CR1|4|4|
5|5|CR2|4|5|
6|6|CA|1|1|
7|7|BH|2|1|
8|10|CAB NUEVO|1|1|
9|11|Promocional Disciplina nuevo|5|1|
10|12|BH*|\N|\N|
11|13|IGP1|\N|\N|
12|14|IGP2|\N|\N|
13|15|IGP3|\N|\N|
14|16|FH1|\N|\N|
15|17|FH2|\N|\N|
