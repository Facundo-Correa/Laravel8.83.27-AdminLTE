Exportando registros desde: colores
