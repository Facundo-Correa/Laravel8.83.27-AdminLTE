Exportando registros desde: examenes_codigos
1|1|CAB2|1|
2|2|SELECCION|3|
3|3|APTO DE CRÍA|1|
4|4|SUPERIOR|1|
5|5|DCF|3|
6|6|DCFCODO|3|
