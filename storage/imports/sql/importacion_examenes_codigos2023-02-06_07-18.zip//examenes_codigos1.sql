Exportando registros desde: examenes_codigos
