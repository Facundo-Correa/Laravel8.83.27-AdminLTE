Exportando registros desde: apto_cria_apto
