Exportando registros desde: juez_categoria
1|1|CRIANZA|4|
2|2|INTERNACIONAL|3|
3|3|SELECCIÓN|5|
4|4|NACIONAL|2|
5|5|REGIONAL|1|
6|6|HABILITADO|3|
