Exportando registros desde: juez_categoria
