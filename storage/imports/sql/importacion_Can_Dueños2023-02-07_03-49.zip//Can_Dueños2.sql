Exportando registros desde: Can_Dueños
