Exportando registros desde: pruebas_de_adiestramiento
1|01|CA|
2|02|CAB anterior|
3|03|CAB FORMATIVO|
4|04|IPO1|
5|05|IPO2|
6|06|IPO3|
7|07|Promocional Disciplina|
8|08|Promocional Formativo|
9|09|Promocional Rastro|
10|10|CAB|
11|11|Promocional Disciplina Nuevo|
12|12|IPO1 SECCION A|
13|13|IPO1 SECCION B|
14|14|IPO 1 SECCION C|
15|15|IPO 3 SECCION A|
16|16|IPO 3 SECCION B|
17|17|IPO 3 SECCION C|
