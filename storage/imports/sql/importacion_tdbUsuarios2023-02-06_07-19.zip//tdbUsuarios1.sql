Exportando registros desde: tdbUsuarios
