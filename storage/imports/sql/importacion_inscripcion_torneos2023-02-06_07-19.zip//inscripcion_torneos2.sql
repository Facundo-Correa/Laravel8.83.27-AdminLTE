Exportando registros desde: inscripcion_torneos
