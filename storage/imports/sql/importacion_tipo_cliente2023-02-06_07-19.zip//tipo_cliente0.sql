Exportando registros desde: tipo_cliente
1|1|SOCIO|
2|2|NO SOCIO|
3|3|DELEGACION|
4|4|AGRUPACION|
