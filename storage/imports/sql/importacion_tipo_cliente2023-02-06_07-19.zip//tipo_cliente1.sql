Exportando registros desde: tipo_cliente
