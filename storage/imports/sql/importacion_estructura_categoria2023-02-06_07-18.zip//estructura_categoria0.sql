Exportando registros desde: estructura_categoria
1|1|Machos Seleccionados|24|9999|SI|M|
2|2|Hembras Seleccionadas|24|9999|SI|H|
3|3|Segunda|18|24|SI|\N|
4|4|Tercera|12|18|SI|\N|
5|5|Cuarta|9|12|NO|\N|
6|6|Quinta|6|9|NO|\N|
7|7|Sexta|4|6|NO|\N|
