Exportando registros desde: juez_torneo
