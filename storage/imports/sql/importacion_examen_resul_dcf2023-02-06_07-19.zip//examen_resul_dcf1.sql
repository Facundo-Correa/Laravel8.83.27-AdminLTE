Exportando registros desde: examen_resul_dcf
