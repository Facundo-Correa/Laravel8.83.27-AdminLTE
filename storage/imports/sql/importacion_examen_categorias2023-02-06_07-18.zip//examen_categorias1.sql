Exportando registros desde: examen_categorias
