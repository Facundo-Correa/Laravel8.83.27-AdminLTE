Exportando registros desde: radiologo
