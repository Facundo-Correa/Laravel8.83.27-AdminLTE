Exportando registros desde: tipoExamen
