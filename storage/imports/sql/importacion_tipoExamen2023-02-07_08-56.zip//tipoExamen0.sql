Exportando registros desde: tipoExamen
1|1|Adiestramiento|
2|2|Estructura|
3|3|Estructura y Adiestramiento|
