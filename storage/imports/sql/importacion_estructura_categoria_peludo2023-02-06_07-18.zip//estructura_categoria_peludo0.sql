Exportando registros desde: estructura_categoria_peludo
1|1|Machos Seleccionados|24|9999|si|M|S|
2|2|Hembras Seleccionadas |24|9999|si|H|S|
3|3|Machos Adultos|24|9999|si|M|N|
4|4|Hembras Adultas|24|9999|si|H|N|
5|5|Segunda|18|24|si|\N|\N|
6|6|Tercera|12|18|si|\N|\N|
7|7|Cuarta|9|12|si|\N|\N|
8|8|Quinta|6|9|no|\N|\N|
9|9|Sexta|4|6|no|\N|\N|
