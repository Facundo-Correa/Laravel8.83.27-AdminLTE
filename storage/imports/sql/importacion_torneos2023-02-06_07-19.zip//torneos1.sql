Exportando registros desde: torneos
