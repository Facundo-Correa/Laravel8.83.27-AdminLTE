Exportando registros desde: r_poa_pla
