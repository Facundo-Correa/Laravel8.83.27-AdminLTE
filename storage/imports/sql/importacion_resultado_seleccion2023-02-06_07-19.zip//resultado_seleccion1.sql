Exportando registros desde: resultado_seleccion
